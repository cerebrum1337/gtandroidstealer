Open eclipse and create a new java project.
Then simply copy the extracted content and paste it in source folder inside of eclipse.
