package com.example.gtface;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.example.sendemail";
  
  public static final String BUILD_TYPE = "debug";
  
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  
  public static final String FLAVOR = "";
  
  public static final int VERSION_CODE = 1;
  
  public static final String VERSION_NAME = "1.0";
}


/* Location:              C:\Users\Tbrin\Downloads\System_Freezer_1-dex2jar.jar!\com\example\gtface\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */