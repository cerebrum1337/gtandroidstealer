package androidx.versionedparcelable;

public final class R {}


/* Location:              C:\Users\Tbrin\Downloads\System_Freezer_1-dex2jar.jar!\androidx\versionedparcelable\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */