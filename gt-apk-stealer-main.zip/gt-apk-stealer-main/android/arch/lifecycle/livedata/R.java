package android.arch.lifecycle.livedata;

public final class R {}


/* Location:              C:\Users\Tbrin\Downloads\System_Freezer_1-dex2jar.jar!\android\arch\lifecycle\livedata\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */